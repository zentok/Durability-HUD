package dev.durabilityhud;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.Mth;

public class DurabilityHudClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.durabilityhud";
    private static KeyMapping toggleKey;
    private static KeyMapping settingsKey;

    @Override
    public void onInitializeClient() {
        DurabilityConfig.load();
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.durabilityhud.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.durabilityhud.settings", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_U, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(DurabilityHudClient::tick);
        HudRenderCallback.EVENT.register(DurabilityHud::render);
        // durability line in every item tooltip (vanilla shows it only with F3+H)
        ItemTooltipCallback.EVENT.register((stack, flag, lines) -> {
            if (!DurabilityConfig.get().showTooltip || !stack.isDamageableItem() || flag.isAdvanced()) {
                return;
            }
            int max = stack.getMaxDamage();
            int cur = max - stack.getDamageValue();
            float frac = max <= 0 ? 1.0F : Mth.clamp((float) cur / (float) max, 0.0F, 1.0F);
            int color = Mth.hsvToRgb(frac / 3.0F, 0.75F, 1.0F);
            lines.add(Component.translatable("durabilityhud.tooltip", cur, max).withStyle(Style.EMPTY.withColor(color)));
        });
    }

    private static void tick(Minecraft client) {
        DurabilityHud.tick(client);
        DurabilityConfig cfg = DurabilityConfig.get();
        while (toggleKey.consumeClick()) {
            cfg.enabled = !cfg.enabled;
            DurabilityConfig.save();
            message(client, Component.translatable(cfg.enabled ? "durabilityhud.message.on" : "durabilityhud.message.off"));
        }
        while (settingsKey.consumeClick()) {
            if (client.screen == null) {
                client.setScreen(new DurabilitySettingsScreen(null));
            }
        }
    }

    private static void message(Minecraft client, Component text) {
        if (client.player != null) {
            client.player.displayClientMessage(text, true);
        }
    }
}
