from PIL import Image, ImageDraw, ImageFont
import colorsys, math
S=3
W,H=1130,1270
im=Image.new("RGBA",(W,H),(30,34,40,255))
d=ImageDraw.Draw(im,"RGBA")
F=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",8*S)
FB=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",8*S)
ox=oy=0
def rgb(c): return ((c>>16)&255,(c>>8)&255,c&255)
def col(c,a=None):
    if c>0xFFFFFF or a is not None:
        a=(c>>24)&255 if a is None else a
        return rgb(c)+(a,)
    return rgb(c)+(255,)
def fill(x1,y1,x2,y2,c):
    if x2<=x1 or y2<=y1: return
    d.rectangle([ox+x1*S,oy+y1*S,ox+x2*S-1,oy+y2*S-1],fill=col(c))
def text(s,x,y,c,shadow=True,font=None):
    f=font or F
    if shadow: d.text((ox+x*S+S,oy+y*S+S-2),s,font=f,fill=(0,0,0,150))
    d.text((ox+x*S,oy+y*S-2),s,font=f,fill=col(c))
def ctext(s,cx,y,c,font=None):
    f=font or F; w=d.textlength(s,font=f)/S
    text(s,cx-w/2,y,c,True,f)
def tw(s): return d.textlength(s,font=F)/S
def box(x,y,w,h,b,f):
    fill(x+1,y,x+w-1,y+h,b); fill(x,y+1,x+w,y+h-1,b); fill(x+1,y+1,x+w-1,y+h-1,f)
def item(x,y,kind):
    pal={"c":(0x4AEDD9,0x1FA8A0,0x0E6E78),"b":(0x4AEDD9,0x1FA8A0,0x0E6E78),"p":(0x4AEDD9,0x1FA8A0,0x0E6E78)}[kind]
    if kind=="c":
        fill(x+2,y+1,x+6,y+4,pal[0]);fill(x+10,y+1,x+14,y+4,pal[0]);fill(x+3,y+3,x+13,y+14,pal[1]);fill(x+5,y+3,x+11,y+6,pal[2]);fill(x+3,y+11,x+13,y+14,pal[2])
    elif kind=="b":
        fill(x+2,y+7,x+7,y+13,pal[1]);fill(x+9,y+7,x+14,y+13,pal[1]);fill(x+2,y+11,x+7,y+13,pal[2]);fill(x+9,y+11,x+14,y+13,pal[2]);fill(x+2,y+7,x+7,y+8,pal[0]);fill(x+9,y+7,x+14,y+8,pal[0])
    else:
        fill(x+2,y+2,x+12,y+4,pal[0]);fill(x+6,y+4,x+8,y+15,0x8B5A2B)
def hsv(f): 
    r,g,b=colorsys.hsv_to_rgb(f/3.0,1,1); return (int(r*255)<<16)|(int(g*255)<<8)|int(b*255)
def shade(c,f):
    r,g,b=rgb(c); return (min(255,int(r*f))<<16)|(min(255,int(g*f))<<8)|min(255,int(b*f))
def fillbar(x,y,w,h,fr,c):
    f=round(w*fr); 
    if f<=0 and fr>0: f=1
    if f<=0: return
    hh=max(1,h//2); fill(x,y,x+f,y+hh,0xFF000000|shade(c,1.15)); fill(x,y+hh,x+f,y+h,0xFF000000|shade(c,0.75))
def fa(bg,rgbc): a=min(255,100+round(bg*1.55)); return (a<<24)|rgbc
def hexa(x,y,w,h,b,f):
    for r in range(h):
        dd=abs(r+0.5-h/2)/(h/2); i=round(dd*5)
        fill(x+i,y+r,x+w-i,y+r+1,b)
        if 0<r<h-1: fill(x+i+1,y+r,x+w-i-1,y+r+1,f)

def entry(style,kind,fr,idx,w,x,y,bg=60):
    pct=round(fr*100); label=f"{pct}%"; t=tw(label); base=hsv(fr); tc=0xFF000000|base
    if style=="fantasy":
        acc=0xFF000000|base; bw=w-31
        box(x,y,w,24,0xFF6B4A2B,fa(bg,0x0E2528))
        for a in ((x+2,y+2,x+w-2,y+3),(x+2,y+21,x+w-2,y+22),(x+2,y+3,x+3,y+21),(x+w-3,y+3,x+w-2,y+21)): fill(*a,0xFFB8863A)
        mx=x+w//2; fill(mx,y,mx+1,y+1,0xFFFFB347);fill(mx-1,y+1,mx+2,y+2,0xFFFFB347);fill(mx-2,y+2,mx+3,y+3,0xFFFFB347);fill(mx-1,y+3,mx+2,y+4,0xFFFFB347);fill(mx,y+2,mx+1,y+3,0xFFFFE9A8)
        item(x+5,y+4,kind); text(label,x+25,y+5,tc)
        fill(x+24,y+13,x+26+bw,y+19,0xFF3A2A18);fill(x+25,y+14,x+25+bw,y+18,0xFF061214);fillbar(x+25,y+14,bw,4,fr,base)
    elif style=="scifi":
        bw=w-29
        box(x,y,w,22,0xFF8794A0,fa(bg,0x0B1822)); fill(x+1,y+1,x+w-1,y+2,0x30C8D8E8)
        mx=x+w//2; fill(mx-8,y,mx+8,y+1,0xFF000000|base); fill(mx-8,y+21,mx+8,y+22,0xFF000000|base)
        item(x+4,y+3,kind); text(label,x+24,y+4,tc)
        fill(x+23,y+13,x+25+bw,y+18,0xFF2A4452);fill(x+24,y+14,x+24+bw,y+17,0xFF050C12);fillbar(x+24,y+14,bw,3,fr,base)
    elif style=="rust":
        bw=w-33
        box(x,y,w,24,0xFF74706A,fa(bg,0x262524))
        for i in range(w//2):
            sx=x+2+(i*37+idx*11)%(w-4); sy=y+2+(i*17+idx*5)%(24-4)
            fill(sx,sy,sx+1,sy+1,0x50888078 if i%3==0 else 0x50000000)
        for rx,ry in ((x+2,y+2),(x+w-4,y+2),(x+2,y+20),(x+w-4,y+20)): fill(rx,ry,rx+2,ry+2,0xFFA9A398)
        fill(x+4,y+3,x+23,y+21,0xFF5A3A24)
        for k in range(4,23,3): fill(x+k,y+3,x+k+1,y+4,0xFFC8A878);fill(x+k,y+20,x+k+1,y+21,0xFFC8A878)
        for k in range(3,21,3): fill(x+4,y+k,x+5,y+k+1,0xFFC8A878);fill(x+22,y+k,x+23,y+k+1,0xFFC8A878)
        item(x+5,y+4,kind); text(label,x+27,y+4,tc)
        fill(x+26,y+13,x+28+bw,y+20,0xFF8A857C);fill(x+27,y+14,x+27+bw,y+19,0xFF110808);fillbar(x+27,y+14,bw,5,fr,base)
    elif style=="dragon":
        bw=w-30
        box(x,y,w,24,0xFF8A786C,fa(bg,0x2C2623)); fill(x+1,y+1,x+w-1,y+2,0x30FFFFFF)
        fill(x+3,y+3,x+21,y+21,0xFF5C2E1A);fill(x+3,y+3,x+21,y+4,0xFFB5683A);fill(x+3,y+3,x+4,y+21,0xFFB5683A);fill(x+3,y+20,x+21,y+21,0xFF2B140A);fill(x+20,y+3,x+21,y+21,0xFF2B140A)
        item(x+4,y+4,kind); text(label,x+25,y+5,tc)
        fill(x+24,y+13,x+26+bw,y+20,0xFF0E0B0A);fill(x+25,y+14,x+25+bw,y+19,0xFF2A0E08);fillbar(x+25,y+14,bw,5,fr,base)
        fill(x+25,y+14,x+25+round(bw*fr),y+15,0x60FFE0A0)
    elif style=="hex":
        bw=w-31
        hexa(x,y+1,26,20,0xFF000000|base,0xFF0B1B33); item(x+5,y+3,kind); text(label,x+29,y+1,tc)
        box(x+27,y+10,bw+4,11,0xFF2B4F80,0xFF0A1830)
        n=bw//4; lit=0 if fr<=0 else max(1,math.ceil(fr*n))
        for i in range(n): fill(x+29+i*4,y+12,x+32+i*4,y+19,(0xFF000000|base) if i<lit else 0xFF14233A)
    elif style=="jade":
        bw=w-31; gold=0xFFC9A227
        box(x,y,w,24,0xFF7A5C12,fa(bg,0x0C2A22))
        fill(x+1,y+1,x+w-1,y+2,gold);fill(x+1,y+22,x+w-1,y+23,gold);fill(x+1,y+2,x+2,y+22,gold);fill(x+w-2,y+2,x+w-1,y+22,gold)
        for rx,ry in ((x+2,y+2),(x+w-4,y+2),(x+2,y+20),(x+w-4,y+20)): fill(rx,ry,rx+2,ry+2,0xFF3DDC84)
        fill(x+4,y+3,x+22,y+21,gold);fill(x+5,y+4,x+21,y+20,0xFF081C16)
        item(x+5,y+4,kind); text(label,x+26,y+5,tc)
        fill(x+25,y+13,x+27+bw,y+20,gold);fill(x+26,y+14,x+26+bw,y+19,0xFF06140F);fillbar(x+26,y+14,bw,5,fr,base)
        fill(x+26,y+14,x+26+round(bw*fr),y+15,0x66FFFFFF)
WID={"fantasy":31+30,"scifi":29+30,"rust":33+30,"dragon":30+30,"hex":31+44,"jade":31+30}
def width(style,lab): 
    base={"fantasy":31,"scifi":29,"rust":33,"dragon":30,"hex":31,"jade":31}[style]
    return base+max(int(math.ceil(tw(lab))),44 if style=="hex" else 30)
def sample(style,x,y,sc=None):
    for i,(kind,fr) in enumerate((("c",0.20),("b",0.65))):
        w=WID[style] if style!="x" else 0
        w=max(width(style,f"{round(f*100)}%") for f in (0.2,0.65))
        entry(style,kind,fr,i,w,x,y+i*(24+3),60)

# ---------------- menu ----------------
d.rectangle([0,0,W,780],fill=(46,54,64,255))
cx=170+10; ox=oy=0
def ui_button(x,y,w,h,label,kind=0,active=True,hover=False):
    if not active: f,b,t=0xFF2486E0,0xFF9FE4FF,0xFFFFFFFF
    elif kind==1: f,b,t=0xFF5E9E17,0xFFB6F03C,0xFFF1FFD0
    else: f,b,t=(0xFF1D5698 if hover else 0xFF143C6E),(0xFF7CCBFF if hover else 0xFF2F8AD8),0xFFCDE9FF
    box(x,y,w,h,b,f); fill(x+1,y+1,x+w-1,y+2,0x30FFFFFF); fill(x+1,y+h-2,x+w-1,y+h-1,0x30000000)
    ctext(label,x+w//2,y+(h-8)//2,t)
def slider(x,y,w,label,v):
    box(x,y,w,20,0xFF2F8AD8,0xFF0A1B36); inner=w-4; n=inner//4; lit=round(v*n)
    for i in range(n): fill(x+2+i*4,y+3,x+5+i*4,y+17,0xFF2EA8FF if i<lit else 0xFF11284A)
    kx=x+2+round(v*(inner-4)); fill(kx,y+1,kx+4,y+19,0xFFBDF0FF); ctext(label,x+w//2,y+6,0xFFFFFFFF)
top,bottom=12,236
ox=60
box(cx-172,top-2,344,bottom-top+4,0xFF050D1A,0xFF050D1A)
box(cx-170,top,340,bottom-top,0xFF3B9BE8,0xF0102448)
fill(cx-168,top+2,cx+168,top+3,0x30FFFFFF)
for a in ((cx-174,top+6,cx-173,top+18),(cx+173,top+6,cx+174,top+18),(cx-174,bottom-18,cx-173,bottom-6),(cx+173,bottom-18,cx+174,bottom-6)): fill(*a,0xFF7CCBFF)
box(cx-80,2,160,18,0xFF050D1A,0xFF050D1A);box(cx-78,3,156,16,0xFF7CCBFF,0xFF1B5FA8);fill(cx-76,4,cx+76,5,0x40FFFFFF)
ctext("Durability HUD",cx,7,0xFFFFFFFF)
fill(cx-162,24,cx+162,48,0x66050D1A)
for i,n in enumerate(("Расположение","Стиль","Функции")): ui_button(cx-155+i*105,26,100,20,n,0,i!=1)
names=[("classic","Классика"),("panel","Панель"),("bars","Полоски"),("compact","Компактный"),("seasons","Сезоны"),("slots","Ячейки"),("minimal","Минимум"),("neon","Неон"),
       ("fantasy","Руны"),("scifi","Sci-Fi"),("rust","Ржавчина"),("dragon","Дракон"),("hex","Гекс"),("jade","Нефрит")]
page=1; sel="hex"
for i in range(8):
    idx=page*8+i
    if idx>=len(names): break
    key,nm=names[idx]; x=cx-158+(i%4)*80; y=52+(i//4)*48; w,h=76,44
    s=(key==sel); b=0xFFB6F03C if s else 0xFF2F8AD8
    box(x,y,w,h,b,0xFF0A1B36)
    if s:
        for a in ((x+2,y+1,x+w-2,y+2),(x+2,y+h-2,x+w-2,y+h-1),(x+1,y+2,x+2,y+h-2),(x+w-2,y+2,x+w-1,y+h-2)): fill(*a,0xFF5E9E17)
    # mini preview
    ww=max(width(key,"20%"),width(key,"65%")); th=24*2+3; sc=min(0.8,(w-4-6)/ww,(h-14-4)/th)
    # render preview scaled: draw into temp then paste
    tmp=Image.new("RGBA",(int(ww*S)+4,int(th*S)+4),(0,0,0,0)); oim=im; od=d
    im=tmp; d=ImageDraw.Draw(im,"RGBA"); ox_,oy_=ox,oy; ox=oy=0
    sample(key,0,0)
    im=oim; d=od; ox,oy=ox_,oy_
    pw=int(ww*S*sc); ph=int(th*S*sc); t2=tmp.resize((max(1,pw),max(1,ph)),Image.NEAREST)
    px=ox+ (x+2+(w-4-ww*sc)/2)*S; py=oy+(y+2+(h-14-th*sc)/2)*S
    im.alpha_composite(t2,(int(px),int(py)))
    fill(x+2,y+h-12,x+w-2,y+h-2,0xFF2F5A0E if s else 0xFF0E2A52)
    ctext(nm,x+w//2,y+h-11,0xFFE9FFC4 if s else 0xFFCDE9FF)
ui_button(cx-60,148,28,14,"<");ui_button(cx+32,148,28,14,">");ctext("2 / 2",cx,152,0xFFCDE9FF)
slot=0
def opt(label,kind,val=None):
    global slot
    x=cx+(-155 if slot%2==0 else 5); y=168+(slot//2)*24; slot+=1
    if kind=="cycle": ui_button(x,y,150,20,label)
    elif kind=="toggle":
        box(x,y,150,20,0xFF2F8AD8,0xFF143C6E); fill(x+1,y+1,x+149,y+2,0x30FFFFFF)
        full=label+": "; wl=tw(full)+tw(val); sx=x+75-wl/2
        text(full,sx,y+6,0xFFCDE9FF); text(val,sx+tw(full),y+6,0xFF55FF55)
    else: slider(x,y,150,label,val)
opt("Формат: Проценты","cycle");opt("Цвет по прочности","toggle","Вкл");opt("Тень текста","toggle","Вкл");opt("Фон: 60%","slider",0.6)
ui_button(cx-100,244,200,20,"Готово",1)
im2=im.crop((0,0,W,6*0+640))
# strip
ox=oy=0
d.rectangle([0,780,W,H],fill=(34,38,46,255))
ctext("Новые стили (на скриншоте — как в игре, масштаб ×3)",W//2//S,780//S+4,0xFFFFFFFF)
labels=[("fantasy","Руны"),("scifi","Sci-Fi"),("rust","Ржавчина"),("dragon","Дракон"),("hex","Гекс"),("jade","Нефрит")]
for i,(k,n) in enumerate(labels):
    gx=(i%3)*125+14; gy=(780//S+22)+(i//3)*75
    text(n,gx,gy-1,0xFFB6F03C,True,FB)
    sample(k,gx,gy+10)
im.convert("RGB").save("/mnt/user-data/outputs/durabilityhud-menu-styles3.png")
print("ok")
