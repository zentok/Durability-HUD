package dev.durabilityhud;

public enum HudStyle {
    CLASSIC, PANEL, BARS, COMPACT, SEASONS, SLOTS, MINIMAL, NEON,
    FANTASY, SCIFI, RUST, DRAGON, HEX, JADE;

    public HudStyle next() {
        HudStyle[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public String key() {
        return "durabilityhud.style." + name().toLowerCase();
    }
}
