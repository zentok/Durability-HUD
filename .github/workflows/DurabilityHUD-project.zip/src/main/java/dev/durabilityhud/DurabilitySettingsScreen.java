package dev.durabilityhud;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/** Settings with three sections: location, style and functions. The HUD is drawn live behind it. */
public class DurabilitySettingsScreen extends Screen {
    private static final String[] TABS = {"location", "style", "functions"};
    private static int lastTab = 0;

    private final Screen parent;
    private static int stylePage = -1;
    private static final int PAGE = 8;

    private int tab = lastTab;
    private int slot;
    private int listTop = 58;

    public DurabilitySettingsScreen(Screen parent) {
        super(Component.translatable("durabilityhud.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        slot = 0;
        listTop = 58;
        DurabilityConfig c = DurabilityConfig.get();
        int cx = this.width / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            UiButton tabButton = new UiButton(cx - 155 + i * 105, 26, 100, 20,
                    Component.translatable("durabilityhud.tab." + TABS[i]), 0, b -> {
                tab = index;
                lastTab = index;
                this.rebuildWidgets();
            });
            tabButton.active = i != tab;
            this.addRenderableWidget(tabButton);
        }

        if (tab == 0) {
            cycle(() -> label("position", Component.translatable(c.position.key())), () -> c.position = c.position.next());
            cycle(() -> label("orientation", Component.translatable(c.orientation.key())), () -> c.orientation = c.orientation.next());
            slider("offset_x", -400, 400, c.offsetX, " px", v -> c.offsetX = v);
            slider("offset_y", -400, 400, c.offsetY, " px", v -> c.offsetY = v);
            slider("scale", 50, 200, c.scalePercent, "%", v -> c.scalePercent = v);
        } else if (tab == 1) {
            HudStyle[] styles = HudStyle.values();
            int pages = (styles.length + PAGE - 1) / PAGE;
            if (stylePage < 0) {
                stylePage = c.style.ordinal() / PAGE;
            }
            stylePage = Math.min(stylePage, pages - 1);
            for (int i = 0; i < PAGE; i++) {
                int idx = stylePage * PAGE + i;
                if (idx >= styles.length) {
                    break;
                }
                final HudStyle st = styles[idx];
                this.addRenderableWidget(new StyleCard(cx - 158 + (i % 4) * 80, 52 + (i / 4) * 48, 76, 44, st,
                        () -> c.style = st));
            }
            UiButton prev = new UiButton(cx - 60, 148, 28, 14, Component.literal("<"), 0, b -> {
                stylePage = (stylePage + pages - 1) % pages;
                this.rebuildWidgets();
            });
            UiButton next = new UiButton(cx + 32, 148, 28, 14, Component.literal(">"), 0, b -> {
                stylePage = (stylePage + 1) % pages;
                this.rebuildWidgets();
            });
            prev.active = pages > 1;
            next.active = pages > 1;
            this.addRenderableWidget(prev);
            this.addRenderableWidget(next);
            listTop = 168;
            cycle(() -> label("format", Component.translatable(c.format.key())), () -> c.format = c.format.next());
            toggle("color", () -> c.colorByDurability, v -> c.colorByDurability = v);
            toggle("shadow", () -> c.textShadow, v -> c.textShadow = v);
            slider("background", 0, 100, c.backgroundOpacity, "%", v -> c.backgroundOpacity = v);
        } else {
            toggle("enabled", () -> c.enabled, v -> c.enabled = v);
            toggle("show_armor", () -> c.showArmor, v -> c.showArmor = v);
            toggle("show_main", () -> c.showMainHand, v -> c.showMainHand = v);
            toggle("show_off", () -> c.showOffHand, v -> c.showOffHand = v);
            toggle("hide_full", () -> c.hideFullDurability, v -> c.hideFullDurability = v);
            toggle("low_warning", () -> c.lowWarning, v -> c.lowWarning = v);
            slider("threshold", 1, 50, c.warningThreshold, "%", v -> c.warningThreshold = v);
            toggle("warning_sound", () -> c.warningSound, v -> c.warningSound = v);
            toggle("hide_debug", () -> c.hideWithDebug, v -> c.hideWithDebug = v);
            toggle("tooltip", () -> c.showTooltip, v -> c.showTooltip = v);
            this.addRenderableWidget(new UiButton(cx + 5, listTop + (slot / 2) * 24, 150, 20,
                    Component.translatable("durabilityhud.option.reset"), 0, b -> {
                DurabilityConfig.reset();
                this.rebuildWidgets();
            }));
        }

        this.addRenderableWidget(new UiButton(cx - 100, this.height - 28, 200, 20, CommonComponents.GUI_DONE, 1,
                b -> this.onClose()));
    }

    private static Component label(String key, Component value) {
        return Component.translatable("durabilityhud.option." + key).append(": ").append(value);
    }

    private int nextX() {
        return this.width / 2 + (slot % 2 == 0 ? -155 : 5);
    }

    private int nextY() {
        return listTop + (slot / 2) * 24;
    }

    private void cycle(Supplier<Component> label, Runnable action) {
        int x = nextX();
        int y = nextY();
        slot++;
        this.addRenderableWidget(new UiButton(x, y, 150, 20, label.get(), 0, b -> {
            action.run();
            b.setMessage(label.get());
        }));
    }

    private void toggle(String key, BooleanSupplier getter, Consumer<Boolean> setter) {
        cycle(() -> label(key, Component.empty().append(getter.getAsBoolean() ? CommonComponents.OPTION_ON : CommonComponents.OPTION_OFF)
                        .withStyle(getter.getAsBoolean() ? ChatFormatting.GREEN : ChatFormatting.RED)),
                () -> setter.accept(!getter.getAsBoolean()));
    }

    private void slider(String key, int min, int max, int value, String suffix, IntConsumer setter) {
        int x = nextX();
        int y = nextY();
        slot++;
        this.addRenderableWidget(new IntSlider(x, y, 150, "durabilityhud.option." + key, min, max, value, suffix, setter));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int cx = this.width / 2;
        int top = 12;
        int bottom = this.height - 36;
        // dark outer frame, bright blue line, navy body (sci-fi panel style)
        box(g, cx - 172, top - 2, 344, bottom - top + 4, 0xFF050D1A, 0xFF050D1A);
        box(g, cx - 170, top, 340, bottom - top, 0xFF3B9BE8, 0xF0102448);
        g.fill(cx - 168, top + 2, cx + 168, top + 3, 0x30FFFFFF);
        // corner ticks
        int tick = 0xFF7CCBFF;
        g.fill(cx - 174, top + 6, cx - 173, top + 18, tick);
        g.fill(cx + 173, top + 6, cx + 174, top + 18, tick);
        g.fill(cx - 174, bottom - 18, cx - 173, bottom - 6, tick);
        g.fill(cx + 173, bottom - 18, cx + 174, bottom - 6, tick);
        // header tab
        box(g, cx - 80, 2, 160, 18, 0xFF050D1A, 0xFF050D1A);
        box(g, cx - 78, 3, 156, 16, 0xFF7CCBFF, 0xFF1B5FA8);
        g.fill(cx - 76, 4, cx + 76, 5, 0x40FFFFFF);
        g.drawCenteredString(this.font, this.title, cx, 7, 0xFFFFFFFF);
        // tab bar and list backdrop
        g.fill(cx - 162, 24, cx + 162, 48, 0x66050D1A);
        if (tab == 1) {
            int pages = (HudStyle.values().length + PAGE - 1) / PAGE;
            g.drawCenteredString(this.font, (stylePage + 1) + " / " + pages, cx, 152, 0xFFCDE9FF);
        }
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        DurabilityConfig.save();
    }

    @Override
    public void onClose() {
        DurabilityConfig.save();
        this.minecraft.setScreen(parent);
    }

    private static void box(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        g.fill(x + 1, y, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + w, y + h - 1, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    /** Flat sci-fi button: kind 0 = blue, kind 1 = green. An inactive button is drawn as the selected tab. */
    private static final class UiButton extends AbstractButton {
        private final int kind;
        private final Consumer<UiButton> action;

        UiButton(int x, int y, int w, int h, Component label, int kind, Consumer<UiButton> action) {
            super(x, y, w, h, label);
            this.kind = kind;
            this.action = action;
        }

        @Override
        public void onPress() {
            this.action.accept(this);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput output) {
            this.defaultButtonNarrationText(output);
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float delta) {
            Font font = Minecraft.getInstance().font;
            boolean hover = this.isHoveredOrFocused() && this.active;
            int fill;
            int border;
            int text;
            if (!this.active) {
                fill = 0xFF2486E0;
                border = 0xFF9FE4FF;
                text = 0xFFFFFFFF;
            } else if (this.kind == 1) {
                fill = hover ? 0xFF74B91E : 0xFF5E9E17;
                border = 0xFFB6F03C;
                text = 0xFFF1FFD0;
            } else {
                fill = hover ? 0xFF1D5698 : 0xFF143C6E;
                border = hover ? 0xFF7CCBFF : 0xFF2F8AD8;
                text = 0xFFCDE9FF;
            }
            int x = this.getX();
            int y = this.getY();
            box(g, x, y, this.width, this.height, border, fill);
            g.fill(x + 1, y + 1, x + this.width - 1, y + 2, 0x30FFFFFF);
            g.fill(x + 1, y + this.height - 2, x + this.width - 1, y + this.height - 1, 0x30000000);
            g.drawCenteredString(font, this.getMessage(), x + this.width / 2, y + (this.height - 8) / 2, text);
        }
    }

    private static final class StyleCard extends AbstractButton {
        private final HudStyle style;
        private final Runnable onSelect;

        StyleCard(int x, int y, int w, int h, HudStyle style, Runnable onSelect) {
            super(x, y, w, h, Component.translatable(style.key()));
            this.style = style;
            this.onSelect = onSelect;
        }

        @Override
        public void onPress() {
            this.onSelect.run();
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput output) {
            this.defaultButtonNarrationText(output);
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float delta) {
            Font font = Minecraft.getInstance().font;
            boolean selected = DurabilityConfig.get().style == this.style;
            int x = this.getX();
            int y = this.getY();
            int border = selected ? 0xFFB6F03C : this.isHoveredOrFocused() ? 0xFF7CCBFF : 0xFF2F8AD8;
            box(g, x, y, this.width, this.height, border, this.isHoveredOrFocused() ? 0xFF12315A : 0xFF0A1B36);
            if (selected) {
                box(g, x + 1, y + 1, this.width - 2, this.height - 2, 0xFF5E9E17, 0x00000000);
            }
            DurabilityHud.drawPreview(g, font, this.style, x + 2, y + 2, this.width - 4, this.height - 14);
            g.fill(x + 2, y + this.height - 12, x + this.width - 2, y + this.height - 2, selected ? 0xFF2F5A0E : 0xFF0E2A52);
            g.drawCenteredString(font, this.getMessage(), x + this.width / 2, y + this.height - 11, selected ? 0xFFE9FFC4 : 0xFFCDE9FF);
        }
    }

    private static final class IntSlider extends AbstractSliderButton {
        private final String key;
        private final int min;
        private final int max;
        private final String suffix;
        private final IntConsumer setter;

        IntSlider(int x, int y, int w, String key, int min, int max, int value, String suffix, IntConsumer setter) {
            super(x, y, w, 20, Component.empty(), (double) (value - min) / (double) (max - min));
            this.key = key;
            this.min = min;
            this.max = max;
            this.suffix = suffix;
            this.setter = setter;
            this.updateMessage();
        }

        private int current() {
            return this.min + (int) Math.round(this.value * (this.max - this.min));
        }

        @Override
        protected void updateMessage() {
            if (this.key == null) {
                return;
            }
            this.setMessage(Component.translatable(this.key).append(": " + current() + this.suffix));
        }

        @Override
        protected void applyValue() {
            this.setter.accept(current());
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float delta) {
            Font font = Minecraft.getInstance().font;
            int x = this.getX();
            int y = this.getY();
            box(g, x, y, this.width, this.height, this.isHoveredOrFocused() ? 0xFF7CCBFF : 0xFF2F8AD8, 0xFF0A1B36);
            int inner = this.width - 4;
            int n = inner / 4;
            int lit = (int) Math.round(this.value * n);
            for (int i = 0; i < n; i++) {
                int sx = x + 2 + i * 4;
                g.fill(sx, y + 3, sx + 3, y + this.height - 3, i < lit ? 0xFF2EA8FF : 0xFF11284A);
            }
            int kx = x + 2 + (int) Math.round(this.value * (inner - 4));
            g.fill(kx, y + 1, kx + 4, y + this.height - 1, 0xFFBDF0FF);
            g.drawCenteredString(font, this.getMessage(), x + this.width / 2, y + (this.height - 8) / 2, 0xFFFFFFFF);
        }
    }
}
