package dev.durabilityhud;

public enum HudPosition {
    TOP_LEFT, LEFT, BOTTOM_LEFT, TOP_RIGHT, RIGHT, BOTTOM_RIGHT, ABOVE_HOTBAR;

    public HudPosition next() {
        HudPosition[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public String key() {
        return "durabilityhud.position." + name().toLowerCase();
    }

    public boolean isRight() {
        return this == TOP_RIGHT || this == RIGHT || this == BOTTOM_RIGHT;
    }
}
