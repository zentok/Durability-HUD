package dev.durabilityhud;

public enum HudOrientation {
    AUTO, VERTICAL, HORIZONTAL;

    public HudOrientation next() {
        HudOrientation[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public String key() {
        return "durabilityhud.orientation." + name().toLowerCase();
    }
}
