package dev.durabilityhud;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

/** Saved to config/durabilityhud.json. */
public class DurabilityConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static DurabilityConfig instance = new DurabilityConfig();

    // location
    public HudPosition position = HudPosition.LEFT;
    public HudOrientation orientation = HudOrientation.AUTO;
    public int offsetX = 0;
    public int offsetY = 0;
    public int scalePercent = 100;

    // style
    public HudStyle style = HudStyle.CLASSIC;
    public HudFormat format = HudFormat.NUMBERS;
    public boolean colorByDurability = true;
    public boolean textShadow = true;
    public int backgroundOpacity = 55;

    // functions
    public boolean enabled = true;
    public boolean showArmor = true;
    public boolean showMainHand = true;
    public boolean showOffHand = true;
    public boolean hideFullDurability = false;
    public boolean lowWarning = true;
    public int warningThreshold = 10;
    public boolean warningSound = true;
    public boolean hideWithDebug = true;
    public boolean showTooltip = true;

    public static DurabilityConfig get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("durabilityhud.json");
    }

    public static void load() {
        Path path = file();
        if (Files.exists(path)) {
            try {
                DurabilityConfig loaded = GSON.fromJson(Files.readString(path), DurabilityConfig.class);
                if (loaded != null) {
                    instance = loaded;
                    instance.sanitize();
                }
            } catch (Exception e) {
                System.err.println("[Durability HUD] could not read config, using defaults: " + e);
            }
        }
        save();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(instance));
        } catch (IOException e) {
            System.err.println("[Durability HUD] could not save config: " + e);
        }
    }

    public static void reset() {
        instance = new DurabilityConfig();
        save();
    }

    private void sanitize() {
        if (position == null) position = HudPosition.LEFT;
        if (orientation == null) orientation = HudOrientation.AUTO;
        if (style == null) style = HudStyle.CLASSIC;
        if (format == null) format = HudFormat.NUMBERS;
        scalePercent = Math.max(50, Math.min(200, scalePercent));
        offsetX = Math.max(-400, Math.min(400, offsetX));
        offsetY = Math.max(-400, Math.min(400, offsetY));
        backgroundOpacity = Math.max(0, Math.min(100, backgroundOpacity));
        warningThreshold = Math.max(1, Math.min(50, warningThreshold));
    }
}
