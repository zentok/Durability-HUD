package dev.durabilityhud;

import java.util.ArrayList;
import java.util.List;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Draws the durability list on the in-game HUD (and the little style previews in the settings screen). */
public final class DurabilityHud {
    private static final boolean[] LOW = new boolean[6];
    private static List<ItemStack> demo;
    private static List<ItemStack> previewStacks;
    private static final DurabilityConfig PREVIEW_CFG = new DurabilityConfig();

    // Seasons style: bottle-cap dial in the colours of the Seasons mod (winter, spring, summer, autumn)
    private static final int CAP = 28;
    private static final int CAP_SLOTS = 12;
    private static final int[] BRIGHT = {0x7FB8E8, 0x6CC04A, 0xF5C72E, 0xE67E22};
    private static final int[] DIM = {0x3F5F7E, 0x3A6B2A, 0x8A7418, 0x84490F};
    private static final int[] TEXT = {0xBFE9FF, 0x9BE66F, 0xFFD43B, 0xFFA24A};
    private static final ResourceLocation[] CAP_IDS = new ResourceLocation[CAP_SLOTS];
    private static final DynamicTexture[] CAP_TEX = new DynamicTexture[CAP_SLOTS];
    private static final int[] CAP_KEY = new int[CAP_SLOTS];

    private DurabilityHud() {
    }

    private static final class Entry {
        ItemStack stack;
        String label = "";
        int color = 0xFFFFFF;
        int barColor = 0xFFFFFF;
        float frac = 1.0F;
        int textWidth;
        int w;
        int h;
        int index;
    }

    public static void render(GuiGraphics g, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        DurabilityConfig cfg = DurabilityConfig.get();
        if (!cfg.enabled || mc.player == null || mc.options.hideGui) {
            return;
        }
        if (cfg.hideWithDebug && mc.options.renderDebug) {
            return;
        }
        Font font = mc.font;
        boolean settingsOpen = mc.screen instanceof DurabilitySettingsScreen;
        List<Entry> entries = collect(mc, cfg, font);
        if (entries.isEmpty() && settingsOpen) {
            entries = demoEntries(cfg, font);
        }
        if (entries.isEmpty()) {
            return;
        }
        draw(g, cfg, font, entries);
    }

    private static List<Entry> collect(Minecraft mc, DurabilityConfig cfg, Font font) {
        List<Entry> list = new ArrayList<>();
        Player p = mc.player;
        boolean[] present = new boolean[6];
        if (cfg.showArmor) {
            for (int i = 3; i >= 0; i--) {
                present[i] = add(list, p.getInventory().armor.get(i), i, cfg, font);
            }
        }
        if (cfg.showMainHand) {
            present[4] = add(list, p.getMainHandItem(), 4, cfg, font);
        }
        if (cfg.showOffHand) {
            present[5] = add(list, p.getOffhandItem(), 5, cfg, font);
        }
        for (int i = 0; i < LOW.length; i++) {
            if (!present[i]) {
                LOW[i] = false;
            }
        }
        return list;
    }

    private static boolean add(List<Entry> list, ItemStack stack, int slot, DurabilityConfig cfg, Font font) {
        if (stack.isEmpty() || !stack.isDamageableItem()) {
            return false;
        }
        if (cfg.hideFullDurability && !stack.isDamaged()) {
            return false;
        }
        Entry e = build(stack, cfg, font);
        e.index = list.size();
        boolean low = e.frac * 100.0F < cfg.warningThreshold;
        if (cfg.lowWarning && low) {
            applyFlash(e);
            if (!LOW[slot] && cfg.warningSound) {
                Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ITEM_BREAK, 1.4F));
            }
        }
        LOW[slot] = low;
        list.add(e);
        return true;
    }

    private static void applyFlash(Entry e) {
        if ((System.currentTimeMillis() / 350L) % 2L == 0L) {
            e.color = 0xFF3030;
            e.barColor = 0xFF3030;
        } else {
            e.color = 0xFFFFFF;
        }
    }

    private static int seasonColor(float frac) {
        int wedge = frac > 0.75F ? 3 : frac > 0.5F ? 2 : frac > 0.25F ? 1 : 0;
        return TEXT[wedge];
    }

    private static Entry build(ItemStack stack, DurabilityConfig cfg, Font font) {
        Entry e = new Entry();
        e.stack = stack;
        int max = stack.getMaxDamage();
        int cur = max - stack.getDamageValue();
        e.frac = max <= 0 ? 1.0F : Mth.clamp((float) cur / (float) max, 0.0F, 1.0F);
        int percent = Math.round(e.frac * 100.0F);
        if (cfg.style == HudStyle.MINIMAL) {
            e.label = Integer.toString(percent);
        } else {
            switch (cfg.format) {
                case PERCENT:
                    e.label = percent + "%";
                    break;
                case BOTH:
                    e.label = cur + "/" + max + " (" + percent + "%)";
                    break;
                default:
                    e.label = cur + "/" + max;
                    break;
            }
        }
        int base = cfg.colorByDurability ? Mth.hsvToRgb(e.frac / 3.0F, 1.0F, 1.0F) : 0xFFFFFF;
        e.barColor = base;
        if (cfg.style == HudStyle.SEASONS && cfg.colorByDurability) {
            base = seasonColor(e.frac);
        }
        e.color = base;
        e.textWidth = font.width(e.label);
        return e;
    }

    private static List<Entry> demoEntries(DurabilityConfig cfg, Font font) {
        if (demo == null) {
            demo = makeStacks(new Item[] {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS,
                    Items.DIAMOND_BOOTS, Items.DIAMOND_PICKAXE}, new double[] {0.0, 0.2, 0.55, 0.93, 0.35});
        }
        List<Entry> out = new ArrayList<>();
        for (ItemStack s : demo) {
            Entry e = build(s, cfg, font);
            e.index = out.size();
            if (cfg.lowWarning && e.frac * 100.0F < cfg.warningThreshold) {
                applyFlash(e);
            }
            out.add(e);
        }
        return out;
    }

    private static List<ItemStack> makeStacks(Item[] items, double[] used) {
        List<ItemStack> list = new ArrayList<>();
        for (int i = 0; i < items.length; i++) {
            ItemStack s = new ItemStack(items[i]);
            s.setDamageValue((int) (s.getMaxDamage() * used[i]));
            list.add(s);
        }
        return list;
    }

    // ---------- layout ----------

    private static void measure(HudStyle style, Entry e) {
        switch (style) {
            case PANEL:
                e.w = 26 + e.textWidth;
                e.h = 24;
                break;
            case BARS:
                e.w = 20 + Math.max(e.textWidth, 46);
                e.h = 18;
                break;
            case COMPACT:
                e.w = Math.max(16, e.textWidth);
                e.h = 26;
                break;
            case SEASONS:
                e.w = 32 + e.textWidth;
                e.h = CAP;
                break;
            case SLOTS:
                e.w = 22 + e.textWidth;
                e.h = 18;
                break;
            case MINIMAL:
                e.w = 16;
                e.h = 16;
                break;
            case NEON:
                e.w = 30 + e.textWidth;
                e.h = 20;
                break;
            case FANTASY:
                e.w = 31 + Math.max(e.textWidth, 30);
                e.h = 24;
                break;
            case SCIFI:
                e.w = 29 + Math.max(e.textWidth, 30);
                e.h = 22;
                break;
            case RUST:
                e.w = 33 + Math.max(e.textWidth, 30);
                e.h = 24;
                break;
            case DRAGON:
                e.w = 30 + Math.max(e.textWidth, 30);
                e.h = 24;
                break;
            case HEX:
                e.w = 31 + Math.max(e.textWidth, 44);
                e.h = 22;
                break;
            case JADE:
                e.w = 31 + Math.max(e.textWidth, 30);
                e.h = 24;
                break;
            default:
                e.w = 20 + e.textWidth;
                e.h = 16;
                break;
        }
    }

    private static int gap(HudStyle style) {
        return style == HudStyle.CLASSIC || style == HudStyle.COMPACT || style == HudStyle.SEASONS
                || style == HudStyle.SLOTS || style == HudStyle.MINIMAL || style == HudStyle.PANEL ? 2 : 3;
    }

    /** Styles that are a solid block: in a column all entries get the same width. */
    private static boolean stretches(HudStyle style) {
        switch (style) {
            case PANEL:
            case NEON:
            case FANTASY:
            case SCIFI:
            case RUST:
            case DRAGON:
            case JADE:
                return true;
            default:
                return false;
        }
    }

    private static void draw(GuiGraphics g, DurabilityConfig cfg, Font font, List<Entry> entries) {
        for (Entry e : entries) {
            measure(cfg.style, e);
        }
        int gapV = gap(cfg.style);
        boolean horizontal = cfg.orientation == HudOrientation.HORIZONTAL
                || (cfg.orientation == HudOrientation.AUTO && cfg.position == HudPosition.ABOVE_HOTBAR);
        int totalW = 0;
        int totalH = 0;
        if (horizontal) {
            for (Entry e : entries) {
                totalW += e.w;
                totalH = Math.max(totalH, e.h);
            }
            totalW += 6 * (entries.size() - 1);
        } else {
            for (Entry e : entries) {
                totalW = Math.max(totalW, e.w);
                totalH += e.h;
            }
            totalH += gapV * (entries.size() - 1);
            if (stretches(cfg.style)) {
                for (Entry e : entries) {
                    e.w = totalW;
                }
            }
        }
        float s = cfg.scalePercent / 100.0F;
        int sw = g.guiWidth();
        int sh = g.guiHeight();
        float pw = totalW * s;
        float ph = totalH * s;
        int margin = 4;
        float x;
        float y;
        switch (cfg.position) {
            case TOP_LEFT:
                x = margin;
                y = margin;
                break;
            case BOTTOM_LEFT:
                x = margin;
                y = sh - ph - margin;
                break;
            case TOP_RIGHT:
                x = sw - pw - margin;
                y = margin;
                break;
            case RIGHT:
                x = sw - pw - margin;
                y = (sh - ph) / 2.0F;
                break;
            case BOTTOM_RIGHT:
                x = sw - pw - margin;
                y = sh - ph - margin;
                break;
            case ABOVE_HOTBAR:
                x = (sw - pw) / 2.0F;
                y = sh - 66 - ph;
                break;
            default:
                x = margin;
                y = (sh - ph) / 2.0F;
                break;
        }
        x += cfg.offsetX;
        y += cfg.offsetY;

        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0.0F);
        pose.scale(s, s, 1.0F);
        int cx = 0;
        int cy = 0;
        for (Entry e : entries) {
            drawEntry(g, font, cfg, e, cx, cy);
            if (horizontal) {
                cx += e.w + 6;
            } else {
                cy += e.h + gapV;
            }
        }
        pose.popPose();
    }

    /** Small picture of a style for the settings screen: two sample items inside the given box. */
    public static void drawPreview(GuiGraphics g, Font font, HudStyle style, int bx, int by, int bw, int bh) {
        if (previewStacks == null) {
            previewStacks = makeStacks(new Item[] {Items.DIAMOND_CHESTPLATE, Items.DIAMOND_BOOTS}, new double[] {0.2, 0.65});
        }
        DurabilityConfig p = PREVIEW_CFG;
        p.style = style;
        p.format = HudFormat.PERCENT;
        p.colorByDurability = true;
        p.textShadow = true;
        p.backgroundOpacity = 60;
        List<Entry> list = new ArrayList<>();
        for (int i = 0; i < previewStacks.size(); i++) {
            Entry e = build(previewStacks.get(i), p, font);
            e.index = 8 + i;
            measure(style, e);
            list.add(e);
        }
        int gapV = gap(style);
        int tw = 0;
        int th = 0;
        for (Entry e : list) {
            tw = Math.max(tw, e.w);
            th += e.h;
        }
        th += gapV * (list.size() - 1);
        if (stretches(style)) {
            for (Entry e : list) {
                e.w = tw;
            }
        }
        float s = Math.min(0.8F, Math.min((bw - 6) / (float) tw, (bh - 4) / (float) th));
        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(bx + (bw - tw * s) / 2.0F, by + (bh - th * s) / 2.0F, 0.0F);
        pose.scale(s, s, 1.0F);
        int cy = 0;
        for (Entry e : list) {
            drawEntry(g, font, p, e, 0, cy);
            cy += e.h + gapV;
        }
        pose.popPose();
    }

    private static void drawEntry(GuiGraphics g, Font font, DurabilityConfig cfg, Entry e, int x, int y) {
        int textColor = 0xFF000000 | e.color;
        switch (cfg.style) {
            case PANEL: {
                int alpha = Math.round(cfg.backgroundOpacity * 2.55F);
                g.fill(x, y, x + e.w, y + e.h, alpha << 24);
                g.renderItem(e.stack, x + 3, y + 2);
                g.drawString(font, e.label, x + 23, y + 6, textColor, cfg.textShadow);
                bar(g, x + 3, y + e.h - 5, e.w - 6, 2, e);
                break;
            }
            case BARS: {
                g.renderItem(e.stack, x, y);
                g.drawString(font, e.label, x + 20, y, textColor, cfg.textShadow);
                bar(g, x + 20, y + 11, Math.max(e.textWidth, 46), 4, e);
                break;
            }
            case COMPACT: {
                int ix = x + (e.w - 16) / 2;
                g.renderItem(e.stack, ix, y);
                g.renderItemDecorations(font, e.stack, ix, y);
                g.drawString(font, e.label, x + (e.w - e.textWidth) / 2, y + 17, textColor, cfg.textShadow);
                break;
            }
            case SEASONS: {
                int slot = Math.min(CAP_SLOTS - 1, e.index);
                int key = Math.round(e.frac * 100.0F);
                ensureCap(slot, key, e.frac);
                g.blit(CAP_IDS[slot], x, y, 0, 0, CAP, CAP, CAP, CAP);
                g.renderItem(e.stack, x + 6, y + 6);
                g.drawString(font, e.label, x + 32, y + 10, textColor, cfg.textShadow);
                break;
            }
            case SLOTS: {
                g.fill(x, y, x + 18, y + 18, 0xFF373737);
                g.fill(x + 1, y + 1, x + 18, y + 18, 0xFFFFFFFF);
                g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF8B8B8B);
                g.renderItem(e.stack, x + 1, y + 1);
                g.renderItemDecorations(font, e.stack, x + 1, y + 1);
                g.drawString(font, e.label, x + 22, y + 5, textColor, cfg.textShadow);
                break;
            }
            case MINIMAL: {
                g.renderItem(e.stack, x, y);
                PoseStack pose = g.pose();
                pose.pushPose();
                pose.translate(x + 17 - e.textWidth * 0.7F, y + 9, 200.0F);
                pose.scale(0.7F, 0.7F, 1.0F);
                g.drawString(font, e.label, 0, 0, textColor, true);
                pose.popPose();
                break;
            }
            case NEON: {
                int alpha = Math.round(cfg.backgroundOpacity * 2.55F);
                int accent = 0xFF000000 | e.barColor;
                g.fill(x, y, x + e.w, y + e.h, alpha << 24);
                g.fill(x, y, x + 2, y + e.h, accent);
                int lineW = Math.max(1, Math.round((e.w - 2) * e.frac));
                g.fill(x + 2, y + e.h - 1, x + 2 + lineW, y + e.h, accent);
                g.renderItem(e.stack, x + 6, y + 2);
                g.drawString(font, e.label, x + 26, y + 6, textColor, cfg.textShadow);
                break;
            }
            case FANTASY: {
                int acc = accent(cfg, e, 0x2FE0C8);
                int bw = e.w - 31;
                box(g, x, y, e.w, e.h, 0xFF6B4A2B, fillA(cfg, 0x0E2528));
                g.fill(x + 2, y + 2, x + e.w - 2, y + 3, 0xFFB8863A);
                g.fill(x + 2, y + e.h - 3, x + e.w - 2, y + e.h - 2, 0xFFB8863A);
                g.fill(x + 2, y + 3, x + 3, y + e.h - 3, 0xFFB8863A);
                g.fill(x + e.w - 3, y + 3, x + e.w - 2, y + e.h - 3, 0xFFB8863A);
                int mx = x + e.w / 2;
                g.fill(mx, y, mx + 1, y + 1, 0xFFFFB347);
                g.fill(mx - 1, y + 1, mx + 2, y + 2, 0xFFFFB347);
                g.fill(mx - 2, y + 2, mx + 3, y + 3, 0xFFFFB347);
                g.fill(mx - 1, y + 3, mx + 2, y + 4, 0xFFFFB347);
                g.fill(mx, y + 2, mx + 1, y + 3, 0xFFFFE9A8);
                g.renderItem(e.stack, x + 5, y + 4);
                g.drawString(font, e.label, x + 25, y + 5, textColor, cfg.textShadow);
                g.fill(x + 24, y + 13, x + 26 + bw, y + 19, 0xFF3A2A18);
                g.fill(x + 25, y + 14, x + 25 + bw, y + 18, 0xFF061214);
                fillBar(g, x + 25, y + 14, bw, 4, e.frac, acc);
                break;
            }
            case SCIFI: {
                int acc = accent(cfg, e, 0x2FE6F2);
                int bw = e.w - 29;
                box(g, x, y, e.w, e.h, 0xFF8794A0, fillA(cfg, 0x0B1822));
                g.fill(x + 1, y + 1, x + e.w - 1, y + 2, 0x30C8D8E8);
                int mx = x + e.w / 2;
                g.fill(mx - 8, y, mx + 8, y + 1, solid(acc));
                g.fill(mx - 8, y + e.h - 1, mx + 8, y + e.h, solid(acc));
                g.renderItem(e.stack, x + 4, y + 3);
                g.drawString(font, e.label, x + 24, y + 4, textColor, cfg.textShadow);
                g.fill(x + 23, y + 13, x + 25 + bw, y + 18, 0xFF2A4452);
                g.fill(x + 24, y + 14, x + 24 + bw, y + 17, 0xFF050C12);
                fillBar(g, x + 24, y + 14, bw, 3, e.frac, acc);
                break;
            }
            case RUST: {
                int acc = accent(cfg, e, 0xE02020);
                int bw = e.w - 33;
                box(g, x, y, e.w, e.h, 0xFF74706A, fillA(cfg, 0x262524));
                for (int i = 0; i < e.w / 2; i++) {
                    int sx = x + 2 + (i * 37 + e.index * 11) % (e.w - 4);
                    int sy = y + 2 + (i * 17 + e.index * 5) % (e.h - 4);
                    g.fill(sx, sy, sx + 1, sy + 1, i % 3 == 0 ? 0x50888078 : 0x50000000);
                }
                g.fill(x + 2, y + 2, x + 4, y + 4, 0xFFA9A398);
                g.fill(x + e.w - 4, y + 2, x + e.w - 2, y + 4, 0xFFA9A398);
                g.fill(x + 2, y + e.h - 4, x + 4, y + e.h - 2, 0xFFA9A398);
                g.fill(x + e.w - 4, y + e.h - 4, x + e.w - 2, y + e.h - 2, 0xFFA9A398);
                g.fill(x + 4, y + 3, x + 23, y + 21, 0xFF5A3A24);
                for (int k = 4; k < 23; k += 3) {
                    g.fill(x + k, y + 3, x + k + 1, y + 4, 0xFFC8A878);
                    g.fill(x + k, y + 20, x + k + 1, y + 21, 0xFFC8A878);
                }
                for (int k = 3; k < 21; k += 3) {
                    g.fill(x + 4, y + k, x + 5, y + k + 1, 0xFFC8A878);
                    g.fill(x + 22, y + k, x + 23, y + k + 1, 0xFFC8A878);
                }
                g.renderItem(e.stack, x + 5, y + 4);
                g.drawString(font, e.label, x + 27, y + 4, textColor, cfg.textShadow);
                g.fill(x + 26, y + 13, x + 28 + bw, y + 20, 0xFF8A857C);
                g.fill(x + 27, y + 14, x + 27 + bw, y + 19, 0xFF110808);
                fillBar(g, x + 27, y + 14, bw, 5, e.frac, acc);
                break;
            }
            case DRAGON: {
                int acc = accent(cfg, e, 0xF2701C);
                int bw = e.w - 30;
                box(g, x, y, e.w, e.h, 0xFF8A786C, fillA(cfg, 0x2C2623));
                g.fill(x + 1, y + 1, x + e.w - 1, y + 2, 0x30FFFFFF);
                g.fill(x + 3, y + 3, x + 21, y + 21, 0xFF5C2E1A);
                g.fill(x + 3, y + 3, x + 21, y + 4, 0xFFB5683A);
                g.fill(x + 3, y + 3, x + 4, y + 21, 0xFFB5683A);
                g.fill(x + 3, y + 20, x + 21, y + 21, 0xFF2B140A);
                g.fill(x + 20, y + 3, x + 21, y + 21, 0xFF2B140A);
                g.renderItem(e.stack, x + 4, y + 4);
                g.drawString(font, e.label, x + 25, y + 5, textColor, cfg.textShadow);
                g.fill(x + 24, y + 13, x + 26 + bw, y + 20, 0xFF0E0B0A);
                g.fill(x + 25, y + 14, x + 25 + bw, y + 19, 0xFF2A0E08);
                fillBar(g, x + 25, y + 14, bw, 5, e.frac, acc);
                g.fill(x + 25, y + 14, x + 25 + Math.round(bw * e.frac), y + 15, 0x60FFE0A0);
                break;
            }
            case HEX: {
                int acc = accent(cfg, e, 0x2FD0FF);
                int bw = e.w - 31;
                hex(g, x, y + 1, 26, 20, solid(acc), 0xFF0B1B33);
                g.renderItem(e.stack, x + 5, y + 3);
                g.drawString(font, e.label, x + 29, y + 1, textColor, cfg.textShadow);
                box(g, x + 27, y + 10, bw + 4, 11, 0xFF2B4F80, 0xFF0A1830);
                int n = bw / 4;
                int lit = e.frac <= 0.0F ? 0 : Math.max(1, (int) Math.ceil(e.frac * n));
                for (int i = 0; i < n; i++) {
                    int tx = x + 29 + i * 4;
                    g.fill(tx, y + 12, tx + 3, y + 19, i < lit ? solid(acc) : 0xFF14233A);
                }
                break;
            }
            case JADE: {
                int acc = accent(cfg, e, 0x2ED573);
                int bw = e.w - 31;
                int gold = 0xFFC9A227;
                box(g, x, y, e.w, e.h, 0xFF7A5C12, fillA(cfg, 0x0C2A22));
                g.fill(x + 1, y + 1, x + e.w - 1, y + 2, gold);
                g.fill(x + 1, y + e.h - 2, x + e.w - 1, y + e.h - 1, gold);
                g.fill(x + 1, y + 2, x + 2, y + e.h - 2, gold);
                g.fill(x + e.w - 2, y + 2, x + e.w - 1, y + e.h - 2, gold);
                g.fill(x + 2, y + 2, x + 4, y + 4, 0xFF3DDC84);
                g.fill(x + e.w - 4, y + 2, x + e.w - 2, y + 4, 0xFF3DDC84);
                g.fill(x + 2, y + e.h - 4, x + 4, y + e.h - 2, 0xFF3DDC84);
                g.fill(x + e.w - 4, y + e.h - 4, x + e.w - 2, y + e.h - 2, 0xFF3DDC84);
                g.fill(x + 4, y + 3, x + 22, y + 21, gold);
                g.fill(x + 5, y + 4, x + 21, y + 20, 0xFF081C16);
                g.renderItem(e.stack, x + 5, y + 4);
                g.drawString(font, e.label, x + 26, y + 5, textColor, cfg.textShadow);
                g.fill(x + 25, y + 13, x + 27 + bw, y + 20, gold);
                g.fill(x + 26, y + 14, x + 26 + bw, y + 19, 0xFF06140F);
                fillBar(g, x + 26, y + 14, bw, 5, e.frac, acc);
                g.fill(x + 26, y + 14, x + 26 + Math.round(bw * e.frac), y + 15, 0x66FFFFFF);
                break;
            }
            default: {
                g.renderItem(e.stack, x, y);
                g.drawString(font, e.label, x + 20, y + 4, textColor, cfg.textShadow);
                break;
            }
        }
    }

    private static void bar(GuiGraphics g, int x, int y, int w, int h, Entry e) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF3A3A3A);
        int filled = Math.round(w * e.frac);
        if (filled <= 0 && e.frac > 0.0F) {
            filled = 1;
        }
        g.fill(x, y, x + filled, y + h, 0xFF000000 | e.barColor);
    }


    // ---------- helpers for the themed styles ----------

    private static int solid(int rgb) {
        return 0xFF000000 | rgb;
    }

    private static int shade(int rgb, float f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (gr << 8) | b;
    }

    private static int fillA(DurabilityConfig cfg, int rgb) {
        int a = Math.min(255, 100 + Math.round(cfg.backgroundOpacity * 1.55F));
        return (a << 24) | rgb;
    }

    private static int accent(DurabilityConfig cfg, Entry e, int def) {
        return cfg.colorByDurability || e.barColor == 0xFF3030 ? e.barColor : def;
    }

    /** One-pixel frame with cut corners and a fill. */
    private static void box(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        g.fill(x + 1, y, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + w, y + h - 1, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    private static void fillBar(GuiGraphics g, int x, int y, int w, int h, float frac, int rgb) {
        int f = Math.round(w * frac);
        if (f <= 0 && frac > 0.0F) {
            f = 1;
        }
        if (f <= 0) {
            return;
        }
        int hh = Math.max(1, h / 2);
        g.fill(x, y, x + f, y + hh, solid(shade(rgb, 1.15F)));
        g.fill(x, y + hh, x + f, y + h, solid(shade(rgb, 0.75F)));
    }

    /** Flat-top hexagon, drawn row by row. */
    private static void hex(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        for (int r = 0; r < h; r++) {
            float d = Math.abs((r + 0.5F) - h / 2.0F) / (h / 2.0F);
            int in = Math.round(d * 5.0F);
            g.fill(x + in, y + r, x + w - in, y + r + 1, border);
            if (r > 0 && r < h - 1) {
                g.fill(x + in + 1, y + r, x + w - in - 1, y + r + 1, fill);
            }
        }
    }

    // ---------- Seasons cap dial ----------

    private static void ensureCap(int slot, int key, float frac) {
        if (CAP_TEX[slot] == null) {
            CAP_TEX[slot] = new DynamicTexture(CAP, CAP, true);
            CAP_IDS[slot] = new ResourceLocation("durabilityhud", "dynamic/season_cap_" + slot);
            Minecraft.getInstance().getTextureManager().register(CAP_IDS[slot], CAP_TEX[slot]);
            CAP_KEY[slot] = Integer.MIN_VALUE;
        }
        if (CAP_KEY[slot] != key) {
            NativeImage img = CAP_TEX[slot].getPixels();
            if (img != null) {
                paintCap(img, key / 100.0F);
                CAP_TEX[slot].upload();
            }
            CAP_KEY[slot] = key;
        }
    }

    private static int abgr(int argb) {
        return (argb & 0xFF00FF00) | ((argb & 0xFF) << 16) | ((argb >> 16) & 0xFF);
    }

    private static void paintCap(NativeImage img, float frac) {
        double c = CAP / 2.0;
        for (int y = 0; y < CAP; y++) {
            for (int x = 0; x < CAP; x++) {
                double px = x + 0.5 - c;
                double py = y + 0.5 - c;
                double d = Math.sqrt(px * px + py * py);
                if (d > 13.8) {
                    img.setPixelRGBA(x, y, 0);
                    continue;
                }
                double ang = Math.atan2(px, -py);
                if (ang < 0) {
                    ang += Math.PI * 2;
                }
                double a01 = ang / (Math.PI * 2);
                int argb;
                if (d > 12.4) {
                    boolean light = px < 0 && py < 0;
                    boolean crimp = ((int) (a01 * 28)) % 2 == 0;
                    argb = crimp ? (light ? 0xFF8A6238 : 0xFF6B4A2B) : (light ? 0xFF6B4A2B : 0xFF3F2B18);
                } else if (d > 9.4) {
                    int wedge = Math.min(3, (int) (a01 * 4));
                    double edge = Math.abs(a01 * 4 - Math.rint(a01 * 4));
                    boolean separator = edge < 0.05;
                    boolean lit = a01 < frac;
                    if (separator) {
                        argb = 0xFF1E1812;
                    } else {
                        argb = 0xFF000000 | (lit ? BRIGHT[wedge] : DIM[wedge]);
                    }
                } else if (d > 8.5) {
                    argb = 0xFF120E0A;
                } else {
                    argb = 0xFF2A2018;
                }
                img.setPixelRGBA(x, y, abgr(argb));
            }
        }
    }
}
