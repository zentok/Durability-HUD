package dev.durabilityhud;

public enum HudFormat {
    NUMBERS, PERCENT, BOTH;

    public HudFormat next() {
        HudFormat[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public String key() {
        return "durabilityhud.format." + name().toLowerCase();
    }
}
